import requests
from bs4 import BeautifulSoup
import os
import time
import csv
import re
import uuid
from urllib.parse import urlparse, urljoin

# =========================
# Image Handling
# =========================
class ImageCollection(list):
    def __init__(self, urls, base_url=None, session=None):
        super().__init__(urls)
        self.base_url = base_url
        self.session = session or requests.Session()

    def save_images(self, folder="images", overwrite=False, delay=0.5):
        # SECURITY FIX: Path Traversal Protection
        # We use os.path.basename to ensure the folder is just a folder name
        safe_folder = os.path.basename(folder)
        target_dir = os.path.join(os.getcwd(), safe_folder)
        os.makedirs(target_dir, exist_ok=True)
        
        # SECURITY FIX: Limit number of downloads
        if len(self) > 50:
            print("⚠️ Too many images found. Limiting download to first 50 for safety.")
            download_list = self[:50]
        else:
            download_list = self

        saved_files = []
        for i, url in enumerate(download_list):
            full_url = urljoin(self.base_url, url) if self.base_url else url
            ext = os.path.splitext(full_url)[-1].split("?")[0].lower()
            if ext not in [".jpg", ".jpeg", ".png", ".webp"]:
                ext = ".jpg"
                
            filename = os.path.join(target_dir, f"image_{i+1}{ext}")

            if not overwrite and os.path.exists(filename):
                saved_files.append(filename)
                continue

            try:
                time.sleep(delay)
                resp = self.session.get(full_url, timeout=10)
                resp.raise_for_status()
                with open(filename, "wb") as f:
                    f.write(resp.content)
                saved_files.append(filename)
            except Exception as e:
                print(f"Failed to download {full_url}: {e}")
        return saved_files

# =========================
# Core Web Resource
# =========================
class Web:
    def __init__(self, contact=None):
        self.session = requests.Session()
        machine_id = hex(uuid.getnode())[-6:]
        
        # UPDATED: Version to dev release
        version = "0.1.1.dev1"
        project_home = "https://github.com/ashtwin2win-Z/WebC"
        
        ua = f"WebC/{version} (User: {contact or 'Anonymous'}; ID:{machine_id}; +{project_home})"
        self.session.headers.update({
            "User-Agent": ua,
            "Accept-Encoding": "gzip"
        })

    def _is_safe(self, url):
        """Security Guard: Domain Locking & Protocol Enforcement."""
        parsed = urlparse(url)
        host = parsed.hostname or ""

        # 1. SECURITY: Wikipedia-Only Restriction
        if not host.endswith(".wikipedia.org"):
            raise PermissionError("WebC v0.1.1 is restricted to Wikipedia.org for security.")

        # 2. SECURITY: HTTPS Enforcement
        if parsed.scheme != "https":
            raise PermissionError("Only HTTPS URLs are allowed for safety.")

        # 3. SECURITY: SSRF Protection
        private_ips = ["127.0.0.1", "localhost", "169.254.169.254", "0.0.0.0"]
        if any(ip in host for ip in private_ips):
            raise PermissionError(f"Security Block: Internal address {host} is restricted.")
            
        return True

    def __getitem__(self, url: str):
        # This will now raise PermissionErrors if the check fails
        self._is_safe(url)
        return Resource(url, self.session)

web = Web()

class Resource:
    def __init__(self, url, session):
        self.url = url
        self.session = session
        self._html = None
        self.structure = StructuredView(self)
        self.query = QueryView(self)
        self.task = TaskView(self)

    @property
    def html(self):
        if self._html is None:
            try:
                time.sleep(1.0) 
                response = self.session.get(self.url, timeout=15)
                response.raise_for_status()
                
                # RAM Safety (15MB limit)
                if len(response.content) > 15 * 1024 * 1024:
                    return ""
                self._html = response.text
            except Exception as e:
                print(f"Fetch failed: {e}")
                return ""
        return self._html

    @property
    def soup(self):
        return BeautifulSoup(self.html, "html.parser")

# =========================
# Structured View
# =========================
class StructuredView:
    def __init__(self, resource):
        self.resource = resource

    @property
    def title(self):
        tag = self.resource.soup.find("title")
        return tag.text.strip() if tag else None
    
    @property
    def links(self):
        """Extracts all unique hyperlinks from the page."""
        # Find all <a> tags with an 'href' attribute
        tags = self.resource.soup.find_all("a", href=True)
        urls = []
        for tag in tags:
            # Resolve relative links (like /wiki/Java) to full URLs
            full_url = urljoin(self.resource.url, tag['href'])
            urls.append(full_url)
        
        # Return unique links only, maintaining order
        return list(dict.fromkeys(urls))

    @property
    def images(self):
        content = self.resource.soup.find(id="bodyContent") or self.resource.soup
        all_tags = content.find_all("img")
        
        for noscript in content.find_all("noscript"):
            ns_soup = BeautifulSoup(noscript.text, "html.parser")
            all_tags.extend(ns_soup.find_all("img"))
        
        urls = []
        for img in all_tags:
            src = img.get("srcset", "").split(",")[-1].strip().split(" ")[0] or \
                  img.get("data-src") or img.get("src")
            
            if not src: continue
            if any(x in src.lower() for x in [".svg", "/static/images/"]):
                continue
            urls.append(src)
            
        return ImageCollection(list(dict.fromkeys(urls)), 
                               base_url=self.resource.url, 
                               session=self.resource.session)

    def save_images(self, folder="images", overwrite=False):
        return self.images.save_images(folder=folder, overwrite=overwrite)

    @property
    def tables(self):
        extracted = []
        for table in self.resource.soup.find_all("table", class_="wikitable"):
            grid = {}
            for r_idx, row in enumerate(table.find_all('tr')):
                cells = row.find_all(['td', 'th'])
                c_idx = 0
                for cell in cells:
                    while (r_idx, c_idx) in grid:
                        c_idx += 1
                
                    text = re.sub(r'\[.*?\]', '', cell.get_text(strip=True))
                    rowspan = int(cell.get('rowspan', 1))
                    colspan = int(cell.get('colspan', 1))

                    for r in range(r_idx, r_idx + rowspan):
                        for c in range(c_idx, c_idx + colspan):
                            grid[(r, c)] = text
                    c_idx += colspan

            if not grid: continue
            
            max_r = max(k[0] for k in grid.keys()) + 1
            max_c = max(k[1] for k in grid.keys()) + 1
            data = [[grid.get((r, c), "") for c in range(max_c)] for r in range(max_r)]
            
            name = table.find('caption').get_text(strip=True) if table.find('caption') else None
            extracted.append({"name": name, "data": data})
            
        return extracted

    def save_tables(self, folder="tables"):
        # SECURITY FIX: Path Traversal Protection
        safe_folder = os.path.basename(folder)
        target_dir = os.path.join(os.getcwd(), safe_folder)
        os.makedirs(target_dir, exist_ok=True)
        
        saved_paths = []
        for i, table_obj in enumerate(self.tables, 1):
            raw_name = table_obj["name"] or f"table_{i}"
            # SECURITY: Remove special characters from filenames
            clean_name = re.sub(r'[^\w\-]', '_', raw_name)
            filename = os.path.join(target_dir, f"{clean_name}.csv")
            
            try:
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    csv.writer(f).writerows(table_obj["data"])
                saved_paths.append(filename)
                print(f"Table Saved: {filename}")
            except Exception as e:
                print(f"Error saving {filename}: {e}")
        return saved_paths

# =========================
# Query View
# =========================
class QueryView:
    def __init__(self, resource):
        self.resource = resource

    def __getitem__(self, selector: str):
        return self.resource.soup.select(selector)

class TaskView:
    """Provides intent-driven actions like summarization."""
    def __init__(self, resource):
        self.resource = resource

    def summarize(self, max_chars=500):
        """Extracts text content and cleans it for a short summary."""
        # Focus on paragraph tags for meaningful content
        paragraphs = self.resource.soup.find_all('p')
        text = " ".join([p.get_text().strip() for p in paragraphs])
        
        # Security/Cleanup: Remove citations like [1][2] and extra whitespace
        text = re.sub(r'\[.*?\]', '', text)
        text = re.sub(r'\s+', ' ', text)
        
        if len(text) > max_chars:
            return text[:max_chars].strip() + "..."
        return text.strip()
